module.exports = {
	
  token: process.env.TOKEN || "", // Bot tokeniniz
  mongodbUri: process.env.MONGODB_URI || "", // MongoDB bağlantı URI'niz (isteğe bağlı)
  clientId: "", // Bot ID'niz
  prefix: "", // Prefix ayarı
  
};